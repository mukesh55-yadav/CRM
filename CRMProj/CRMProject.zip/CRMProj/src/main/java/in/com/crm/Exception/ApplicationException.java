package in.com.crm.Exception;

public class ApplicationException extends Exception {
	public ApplicationException(String msg) {
		super(msg);
	}
}
