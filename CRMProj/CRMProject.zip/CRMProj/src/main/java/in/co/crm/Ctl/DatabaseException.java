package in.co.crm.Ctl;

public class DatabaseException extends Exception {

	public DatabaseException(String msg) {
		super(msg);
	}
}
